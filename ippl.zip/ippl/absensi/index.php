<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge" />
    <title>QRcode-with-logo</title>
    <style>
      /* Hapus style untuk #content */
    </style>
  </head>
  <body>
    <!-- Hapus div #passwordPrompt -->
    <div id="content" style="display: block;"> <!-- Ubah display menjadi block -->
      <canvas id="canvas"></canvas>
      <input type="text" id="contentInput" placeholder="Link" />
      <button id="generateBtn">Generate QR Code</button>
      <button id="downloadBtn" style="display: none;">Download QR Code</button>
    </div>

    <script src="QRcode-with-logo.js"></script>
    <script>
      // Hapus event listener untuk submitPassword

      document.getElementById('generateBtn').addEventListener('click', () => {
        const content = document.getElementById('contentInput').value;
        let qrcode = new QrCodeWithLogo({
          canvas: document.getElementById("canvas"),
          content: content,
          width: 400,
          logo: {
            src: "logo.png",
            logoSize: 0.2, // Ukuran logo relatif terhadap QR code
            borderColor: 'transparent', // Menghilangkan border
            borderRadius: 0, // Menghilangkan radius border
            logoBackgroundColor: 'transparent' // Menghilangkan background
          }
        });

        qrcode.toCanvas().then(() => {
          document.getElementById('downloadBtn').style.display = 'block';
        });
      });

      document.getElementById('downloadBtn').addEventListener('click', () => {
        const canvas = document.getElementById('canvas');
        const link = document.createElement('a');
        link.href = canvas.toDataURL('image/png');
        link.download = 'qrcode.png';
        link.click();
      });
    </script>
  </body>
</html>