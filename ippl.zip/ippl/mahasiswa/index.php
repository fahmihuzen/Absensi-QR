<?php
session_start();

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'mahasiswa') {
    header('Location: ../index.php');
    exit();
}

include '../config.php';

// Ambil data mahasiswa
$user_id = $_SESSION['user_id'];
$sql = "SELECT nama, nim FROM users WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();
$stmt->close();

// Dapatkan hari dan tanggal
$hari = date('l');
$tanggal = date('d F Y');

function translateDay($day) {
    $days = [
        'Monday' => 'Senin',
        'Tuesday' => 'Selasa',
        'Wednesday' => 'Rabu',
        'Thursday' => 'Kamis',
        'Friday' => 'Jumat',
        'Saturday' => 'Sabtu',
        'Sunday' => 'Minggu'
    ];
    return $days[$day];
}

$hariIndonesia = translateDay($hari);

// Ambil jadwal kuliah hari ini
$sql = "SELECT m.nama_mk, j.id as jadwal_id, j.jam_mulai, j.jam_selesai, j.ruangan, j.qr_code, u.nama as dosen
        FROM krs k
        JOIN jadwal j ON k.jadwal_id = j.id
        JOIN matakuliah m ON j.matakuliah_id = m.id
        JOIN users u ON j.dosen_id = u.id
        WHERE k.mahasiswa_id = ? AND j.hari = ?
        ORDER BY j.jam_mulai";

$stmt = $conn->prepare($sql);
$stmt->bind_param("is", $user_id, $hariIndonesia);
$stmt->execute();
$jadwal_result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Mahasiswa</title>
    <script src="https://unpkg.com/html5-qrcode"></script>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            line-height: 1.6;
            margin: 0;
            padding: 20px;
            background-color: #f5f5f5;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }

        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }

        .user-info {
            flex-grow: 1;
        }

        h1 {
            color: #333;
            margin: 0;
            font-size: 24px;
        }

        .nim {
            color: #666;
            margin: 5px 0;
        }

        .current-date {
            color: #4CAF50;
            font-weight: bold;
        }

        .logout-form {
            margin-left: 20px;
        }

        .logout-button {
            background-color: #dc3545;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        .logout-button:hover {
            background-color: #c82333;
        }

        .jadwal-hari-ini {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            margin-top: 20px;
        }

        .jadwal-hari-ini h2 {
            color: #2c3e50;
            margin-top: 0;
            padding-bottom: 10px;
            border-bottom: 2px solid #eee;
        }

        .matkul-card {
            background: #f8f9fa;
            border: 1px solid #e9ecef;
            padding: 20px;
            margin: 15px 0;
            border-radius: 8px;
            transition: transform 0.2s;
        }

        .matkul-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }

        .matkul-card h3 {
            color: #2c3e50;
            margin: 0 0 10px 0;
        }

        .matkul-info {
            color: #666;
            margin: 5px 0;
        }

        .absen-button {
            background-color: #4CAF50;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            margin-top: 10px;
            transition: background-color 0.3s;
        }

        .absen-button:hover {
            background-color: #45a049;
        }

        #reader {
            width: 100%;
            max-width: 600px;
            margin: 20px auto;
            display: none;
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }

        .loading {
            display: none;
            text-align: center;
            padding: 20px;
            color: #666;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <div class="user-info">
                <h1>Selamat Datang, <?php echo htmlspecialchars($user['nama']); ?></h1>
                <p class="nim">NIM: <?php echo htmlspecialchars($user['nim']); ?></p>
                <p class="current-date">Hari ini: <?php echo $hariIndonesia . ', ' . $tanggal; ?></p>
            </div>
            <form class="logout-form" method="post" action="../logout.php">
                <button class="logout-button" type="submit">Logout</button>
            </form>
        </div>

        <div class="jadwal-hari-ini">
            <h2>Jadwal Kuliah Hari Ini</h2>
            <?php if ($jadwal_result->num_rows > 0): ?>
                <?php while ($jadwal = $jadwal_result->fetch_assoc()): ?>
                    <div class="matkul-card">
                        <h3><?php echo htmlspecialchars($jadwal['nama_mk']); ?></h3>
                        <p class="matkul-info"><strong>Dosen:</strong> <?php echo htmlspecialchars($jadwal['dosen']); ?></p>
                        <p class="matkul-info"><strong>Waktu:</strong> <?php echo $jadwal['jam_mulai'] . ' - ' . $jadwal['jam_selesai']; ?></p>
                        <p class="matkul-info"><strong>Ruangan:</strong> <?php echo htmlspecialchars($jadwal['ruangan']); ?></p>
                        <button class="absen-button" onclick="buatAbsen('<?php echo $jadwal['jadwal_id']; ?>')">Absen</button>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <p class="info-text">Tidak ada jadwal kuliah hari ini.</p>
            <?php endif; ?>
        </div>

        <div id="reader"></div>
        <div id="loading" class="loading">Memproses QR Code...</div>
    </div>

    <script>
    function buatAbsen(jadwalId) {
        document.getElementById('reader').style.display = 'block';
        
        const html5QrCode = new Html5Qrcode("reader");
        const config = { 
            fps: 10, 
            qrbox: { width: 250, height: 250 },
            aspectRatio: 1.0
        };
        
        html5QrCode.start(
            { facingMode: "environment" },
            config,
            (decodedText, decodedResult) => {
                document.getElementById('loading').style.display = 'block';
                
                // Stop scanner setelah QR terdeteksi
                html5QrCode.stop().then(() => {
                    // Kirim data ke server untuk validasi
                    fetch('../validate_qr.php', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/x-www-form-urlencoded',
                        },
                        body: `qr_data=${encodeURIComponent(decodedText)}&jadwal_id=${jadwalId}`
                    })
                    .then(response => {
                        if (!response.ok) {
                            throw new Error('Network response was not ok');
                        }
                        return response.json();
                    })
                    .then(data => {
                        document.getElementById('loading').style.display = 'none';
                        document.getElementById('reader').style.display = 'none';
                        
                        if (data.success) {
                            alert(data.message);
                            location.reload();
                        } else {
                            alert(data.message || 'QR Code tidak valid');
                        }
                    })
                    .catch(error => {
                        console.error('Error:', error);
                        document.getElementById('loading').style.display = 'none';
                        document.getElementById('reader').style.display = 'none';
                        alert('Terjadi kesalahan saat memvalidasi QR Code. Silakan coba lagi.');
                    });
                }).catch((error) => {
                    console.error('Error stopping scanner:', error);
                    document.getElementById('loading').style.display = 'none';
                    document.getElementById('reader').style.display = 'none';
                    alert('Terjadi kesalahan saat menghentikan scanner.');
                });
            },
            (error) => {
                console.warn("QR Code scanning error:", error);
            }
        ).catch((err) => {
            console.error("Error starting scanner:", err);
            document.getElementById('loading').style.display = 'none';
            document.getElementById('reader').style.display = 'none';
            alert('Tidak dapat mengakses kamera. Pastikan Anda memberikan izin kamera.');
        });
    }
    </script>
</body>
</html>