<?php
session_start();

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'dosen') {
    header('Location: ../index.php');
    exit();
}

include '../config.php';
require_once '../vendor/autoload.php';
use Endroid\QrCode\QrCode;
use Endroid\QrCode\Writer\PngWriter;

// Fungsi untuk generate QR code
function generateQRCode($jadwalId, $timestamp) {
    // Format data QR dengan lebih aman dan konsisten
    $qrData = json_encode([
        'jadwal_id' => $jadwalId,
        'timestamp' => $timestamp,
        'hash' => hash('sha256', $jadwalId . $timestamp . 'secret_key')
    ]);
    
    $qrCode = new QrCode($qrData);
    $writer = new PngWriter();
    $result = $writer->write($qrCode);
    
    return $result->getDataUri();
}

// Tambahkan fungsi translateDay
function translateDay($day) {
    $days = [
        'Monday' => 'Senin',
        'Tuesday' => 'Selasa',
        'Wednesday' => 'Rabu',
        'Thursday' => 'Kamis',
        'Friday' => 'Jumat',
        'Saturday' => 'Sabtu',
        'Sunday' => 'Minggu'
    ];
    return $days[$day];
}

// Modifikasi query untuk mengambil jadwal
$hari = isset($_GET['hari']) ? $_GET['hari'] : translateDay(date('l'));

// Ambil data dosen
$user_id = $_SESSION['user_id'];
$sql = "SELECT nama FROM users WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$dosen = $result->fetch_assoc();
$stmt->close();

// Query untuk mengambil semua jadwal mengajar (untuk sidebar)
$sql_all_jadwal = "SELECT DISTINCT hari FROM jadwal WHERE dosen_id = ? ORDER BY FIELD(hari, 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu', 'Minggu')";
$stmt_all = $conn->prepare($sql_all_jadwal);
$stmt_all->bind_param("i", $user_id);
$stmt_all->execute();
$hari_result = $stmt_all->get_result();

// Query untuk mengambil jadwal mengajar
$sql = "SELECT j.*, m.nama_mk 
        FROM jadwal j 
        JOIN matakuliah m ON j.matakuliah_id = m.id 
        WHERE j.dosen_id = ? AND j.hari = ?";

$stmt = $conn->prepare($sql);
$stmt->bind_param("is", $user_id, $hari);
$stmt->execute();
$jadwal_result = $stmt->get_result();

// Tambahkan query untuk mengambil data absensi
function getAbsensiMahasiswa($jadwal_id, $conn) {
    $sql = "SELECT a.*, u.nama as nama_mahasiswa, u.nim, 
            DATE_FORMAT(a.waktu, '%H:%i:%s') as waktu_absen,
            DATE_FORMAT(a.waktu, '%d-%m-%Y') as tanggal_absen
            FROM absensi a 
            JOIN users u ON a.mahasiswa_id = u.id 
            WHERE a.jadwal_id = ? 
            ORDER BY a.waktu DESC";
    
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        error_log("Prepare failed: " . $conn->error);
        return false;
    }
    
    $stmt->bind_param("i", $jadwal_id);
    if (!$stmt->execute()) {
        error_log("Execute failed: " . $stmt->error);
        return false;
    }
    
    $result = $stmt->get_result();
    $stmt->close();
    return $result;
}

// Generate QR Code
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['generateQR'])) {
    $jadwal_id = $_POST['jadwal_id'];
    $qr_code = uniqid('QR_') . '_' . time();
    
    $sql = "UPDATE jadwal SET qr_code = ? WHERE id = ? AND dosen_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sii", $qr_code, $jadwal_id, $user_id);
    $stmt->execute();
    
    header("Location: " . $_SERVER['PHP_SELF']);
    exit();
}

// Hapus atau comment out baris debugging
// echo "User ID: " . $user_id . "<br>";
// echo "Hari: " . $hari . "<br>";
// var_dump($jadwal_result->fetch_all(MYSQLI_ASSOC));

// Update bagian HTML dan CSS
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Dosen</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            line-height: 1.6;
            margin: 0;
            padding: 20px;
            background-color: #f5f5f5;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }

        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
        }

        h1 {
            color: #333;
            margin: 0;
        }

        .logout-form {
            position: absolute;
            top: 20px;
            right: 20px;
        }

        .logout-button {
            background-color: #dc3545;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        .logout-button:hover {
            background-color: #c82333;
        }

        .jadwal-container {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 20px;
            padding: 20px 0;
        }

        .jadwal-card {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            transition: transform 0.3s ease;
        }

        .jadwal-card:hover {
            transform: translateY(-5px);
        }

        .jadwal-card h3 {
            color: #2c3e50;
            margin-top: 0;
            margin-bottom: 15px;
            font-size: 1.2em;
        }

        .jadwal-card p {
            margin: 8px 0;
            color: #666;
        }

        .qr-button {
            background-color: #4CAF50;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            width: 100%;
            margin-top: 15px;
            transition: background-color 0.3s;
        }

        .qr-button:hover {
            background-color: #45a049;
        }

        .qr-container {
            text-align: center;
            margin-top: 15px;
            padding: 10px;
            background-color: #f8f9fa;
            border-radius: 5px;
        }

        .info-text {
            text-align: center;
            color: #666;
            margin: 20px 0;
        }

        .current-day {
            background-color: #e8f5e9;
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 20px;
            text-align: center;
            color: #2c3e50;
        }

        .absensi-container {
            margin-top: 20px;
            padding-top: 20px;
            border-top: 1px solid #eee;
        }

        .absensi-container h4 {
            color: #2c3e50;
            margin-bottom: 15px;
        }

        .absensi-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
            font-size: 14px;
        }

        .absensi-table th,
        .absensi-table td {
            padding: 8px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        .absensi-table th {
            background-color: #f8f9fa;
            font-weight: bold;
        }

        .absensi-table tr:hover {
            background-color: #f5f5f5;
        }

        .no-data {
            text-align: center;
            color: #666;
            font-style: italic;
            padding: 10px;
        }

        /* Update ukuran card untuk menyesuaikan dengan tabel */
        .jadwal-card {
            min-width: 400px;
        }

        .jadwal-container {
            grid-template-columns: repeat(auto-fill, minmax(400px, 1fr));
        }

        /* Tambahkan style untuk sidebar */
        .layout-container {
            display: flex;
            min-height: 100vh;
        }

        .sidebar {
            width: 200px;
            background-color: #2c3e50;
            padding: 20px;
            color: white;
        }

        .main-content {
            flex: 1;
            padding: 20px;
        }

        .sidebar-title {
            color: white;
            margin-bottom: 20px;
            font-size: 1.2em;
            text-align: center;
        }

        .hari-list {
            list-style: none;
            padding: 0;
        }

        .hari-list li {
            margin-bottom: 10px;
        }

        .hari-list a {
            color: white;
            text-decoration: none;
            padding: 10px;
            display: block;
            border-radius: 5px;
            transition: background-color 0.3s;
        }

        .hari-list a:hover {
            background-color: #34495e;
        }

        .hari-list a.active {
            background-color: #3498db;
        }

        /* Sesuaikan container utama */
        .container {
            max-width: none;
            margin: 0;
            padding: 0;
        }
    </style>
</head>
<body>
    <div class="layout-container">
        <div class="sidebar">
            <h2 class="sidebar-title">Jadwal</h2>
            <ul class="hari-list">
                <?php 
                $hari_indo = ['Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu', 'Minggu'];
                foreach ($hari_indo as $h): 
                    $active = $h === $hari ? 'active' : '';
                ?>
                <li>
                    <a href="?hari=<?php echo $h; ?>" class="<?php echo $active; ?>">
                        <?php echo $h; ?>
                    </a>
                </li>
                <?php endforeach; ?>
            </ul>
        </div>
        
        <div class="main-content">
            <div class="container">
                <div class="header">
                    <h1>Selamat Datang, <?php echo htmlspecialchars($dosen['nama']); ?></h1>
                    <form class="logout-form" method="post" action="../logout.php">
                        <button class="logout-button" type="submit">Logout</button>
                    </form>
                </div>

                <div class="current-day">
                    <h2>Jadwal Hari <?php echo $hari; ?></h2>
                </div>

                <div class="jadwal-container">
                    <?php if ($jadwal_result->num_rows > 0): ?>
                        <?php while ($jadwal = $jadwal_result->fetch_assoc()): ?>
                            <div class="jadwal-card">
                                <h3><?php echo htmlspecialchars($jadwal['nama_mk']); ?></h3>
                                <p><strong>Waktu:</strong> <?php echo $jadwal['jam_mulai'] . ' - ' . $jadwal['jam_selesai']; ?></p>
                                <p><strong>Ruangan:</strong> <?php echo htmlspecialchars($jadwal['ruangan']); ?></p>
                                <button onclick="generateQR('<?php echo $jadwal['id']; ?>')" class="qr-button">Generate QR Code</button>
                                <div id="qrcode-<?php echo $jadwal['id']; ?>" class="qr-container"></div>
                                
                                <!-- Tambahkan tabel absensi -->
                                <div class="absensi-container">
                                    <h4>Daftar Absensi Mahasiswa</h4>
                                    <?php
                                    $absensi_result = getAbsensiMahasiswa($jadwal['id'], $conn);
                                    if ($absensi_result && $absensi_result->num_rows > 0):
                                    ?>
                                    <table class="absensi-table">
                                        <thead>
                                            <tr>
                                                <th>NIM</th>
                                                <th>Nama</th>
                                                <th>Tanggal</th>
                                                <th>Waktu Absen</th>
                                                <th>Status</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php while ($absensi = $absensi_result->fetch_assoc()): ?>
                                            <tr>
                                                <td><?php echo htmlspecialchars($absensi['nim']); ?></td>
                                                <td><?php echo htmlspecialchars($absensi['nama_mahasiswa']); ?></td>
                                                <td><?php echo $absensi['tanggal_absen']; ?></td>
                                                <td><?php echo $absensi['waktu_absen']; ?></td>
                                                <td><?php echo $absensi['status']; ?></td>
                                            </tr>
                                            <?php endwhile; ?>
                                        </tbody>
                                    </table>
                                    <?php else: ?>
                                    <p class="no-data">Belum ada data absensi</p>
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <p class="info-text">Tidak ada jadwal mengajar hari ini.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <script>
    function generateQR(jadwalId) {
        const timestamp = Math.floor(Date.now() / 1000);
        
        fetch('../update_qr.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: `jadwal_id=${jadwalId}&timestamp=${timestamp}`
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            if (data.success) {
                const qrContainer = document.getElementById(`qrcode-${jadwalId}`);
                qrContainer.innerHTML = `
                    <img src="${data.qr_image}" alt="QR Code" style="width: 200px; height: 200px; margin-top: 10px;">
                    <p style="margin-top: 10px; font-size: 12px; color: #666;">QR Code akan kadaluarsa dalam 5 menit</p>
                `;
                
                // Simpan timestamp di localStorage untuk validasi client-side
                localStorage.setItem(`qr_timestamp_${jadwalId}`, timestamp);
                
                alert('QR Code berhasil dibuat!');
            } else {
                alert('Gagal membuat QR Code: ' + (data.message || 'Unknown error'));
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Terjadi kesalahan saat membuat QR Code');
        });
    }
    </script>
</body>
</html>